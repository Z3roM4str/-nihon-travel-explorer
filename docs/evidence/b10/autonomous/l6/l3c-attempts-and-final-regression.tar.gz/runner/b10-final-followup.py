import os,subprocess,pathlib,json,time
root=pathlib.Path('/workspace/nihon/app');out=root/'logs/b10-autonomous/final-followup';out.mkdir(exist_ok=True)
e={**os.environ,'PLAYWRIGHT_BROWSERS_PATH':'/tmp/nihon-browsers','NIHON_CHROMIUM_PATH':'/tmp/nihon-browsers/chromium-1234/chrome-linux64/chrome','NIHON_BASE_URL':'http://127.0.0.1:4181'}
jobs=[('build',['npm','run','build'],{}),('lint',['npm','run','lint'],{}),('vitest',['npm','test','--','--reporter=basic'],{}),('b26-webkit-isolated',['node','scripts/b26-nosotros-check.mjs'],{'NIHON_BROWSER':'webkit','NIHON_WEBKIT_PATH':'/tmp/nihon-webkit'}),('b24',['node','scripts/b24-real-input-audit.mjs','--viewport=390x844'],{}),('a11y',['node','scripts/b10-a11y-surfaces-check.mjs'],{'NIHON_B10_OUT':str(out/'a11y')}),('b19-discovery',['node','scripts/block19-discovery-browser-audit.mjs'],{}),('l1',['node','scripts/b10-l1-check.mjs'],{'NIHON_B10_OUT':str(out/'l1')})]
rows=[]
for n,c,x in jobs:
 print('START',n,flush=True);t=time.time()
 with open(out/(n+'.txt'),'w') as f:r=subprocess.run(c,cwd=root,env={**e,**x},stdout=f,stderr=subprocess.STDOUT)
 rows.append(dict(name=n,command=c,environment=x,exit=r.returncode,seconds=round(time.time()-t,2)));(out/'runs.json').write_text(json.dumps(rows,indent=2));print('DONE',n,r.returncode,flush=True)
 if n in ['build','lint','vitest'] and r.returncode:break
