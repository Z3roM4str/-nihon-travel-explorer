import subprocess,os,json,pathlib,time
root=pathlib.Path('/workspace/nihon/app');out=root/'logs/b10-autonomous/final';out.mkdir(exist_ok=True)
base=os.environ.copy();base.update(PLAYWRIGHT_BROWSERS_PATH='/tmp/nihon-browsers',NIHON_CHROMIUM_PATH='/tmp/nihon-browsers/chromium-1234/chrome-linux64/chrome',NIHON_BASE_URL='http://127.0.0.1:4181')
jobs=[('a11y',['node','scripts/b10-a11y-surfaces-check.mjs'],{'NIHON_B10_OUT':str(out/'a11y')}),('b26-chromium',['node','scripts/b26-nosotros-check.mjs'],{}),('b26-webkit',['node','scripts/b26-nosotros-check.mjs'],{'NIHON_BROWSER':'webkit','NIHON_WEBKIT_PATH':'/tmp/nihon-webkit'}),('b27',['node','scripts/b27-viaje-dias-check.mjs'],{}),('b29',['node','scripts/b29-day-order-tools-check.mjs'],{}),('b28',['node','scripts/b28-reorder-dnd-check.mjs'],{})]
for n,s in [('b30','b30-where-to-sleep'),('b31','b31-reservas-resumen')]:
 for e in ['chromium','webkit']:jobs.append((n+'-'+e,['node','scripts/'+s+'-check.mjs'],{'NIHON_BROWSER':e,**({'NIHON_WEBKIT_PATH':'/tmp/nihon-webkit'} if e=='webkit' else {})}))
for n,s in [('b18-back','b18-browser-back-check'),('b18-a11y','b18-a11y-check'),('b19-discovery','block19-discovery-browser-audit'),('b19-grid','block19-grid-check'),('b19-contrast','block19-contrast-check'),('b20','block20-place-detail-check'),('b25','b25-quiero-ir-check'),('l1','b10-l1-check')]:jobs.append((n,['node','scripts/'+s+'.mjs'],{'NIHON_B10_OUT':str(out/n)}))
for e in ['chromium','webkit']:
 jobs.append(('l2-'+e,['node','scripts/b10-l2-check.mjs'],{'NIHON_BROWSER':e,'NIHON_L2_OUT':str(out/('l2-'+e)),**({'NIHON_WEBKIT_PATH':'/tmp/nihon-webkit'} if e=='webkit' else {})}))
 for n,s in [('motion','b10-motion-check'),('gallery','b10-gallery-motion-check')]:jobs.append((n+'-'+e,['node','scripts/'+s+'.mjs'],{'NIHON_BROWSER':e,'NIHON_B10_OUT':str(out/(n+'-'+e)),**({'NIHON_WEBKIT_PATH':'/tmp/nihon-webkit'} if e=='webkit' else {})}))
rows=[]
for name,cmd,extra in jobs:
 print('START',name,flush=True);t=time.time()
 with open(out/(name+'.txt'),'w') as f:r=subprocess.run(cmd,cwd=root,env={**base,**extra},stdout=f,stderr=subprocess.STDOUT)
 rows.append(dict(name=name,command=cmd,environment=extra,exit=r.returncode,seconds=round(time.time()-t,2)));(out/'runs.json').write_text(json.dumps(rows,indent=2));print('DONE',name,r.returncode,flush=True)
