import os,subprocess,pathlib,json,time
out=pathlib.Path('/workspace/nihon/app/logs/b10-autonomous/legacy');out.mkdir(exist_ok=True)
e={**os.environ,'PLAYWRIGHT_BROWSERS_PATH':'/tmp/nihon-browsers','NIHON_CHROMIUM_PATH':'/tmp/nihon-browsers/chromium-1234/chrome-linux64/chrome'}
rows=[]
for name,script in [('ux','block1-ux-browser-audit'),('backup','block13-portable-backup-browser-audit'),('release','block14-release-readiness-browser-audit'),('b18','b18-regression-check'),('b24','b24-real-input-audit')]:
 for label,root in [('base','/tmp/nihon-b10-base/app'),('final','/workspace/nihon/app')]:
  cmd=['node','scripts/'+script+'.mjs'];
  if name in ['ux','backup','release']:cmd+=['--browser='+e['NIHON_CHROMIUM_PATH']]
  if name=='b24':cmd+=['--viewport=phone']
  print('START',name,label,flush=True)
  try:
   with open(out/(name+'-'+label+'.txt'),'w') as f:r=subprocess.run(cmd,cwd=root,env={**e,'NIHON_BASE_URL':'http://127.0.0.1:4181'},stdout=f,stderr=subprocess.STDOUT,timeout=90)
   code=r.returncode
  except subprocess.TimeoutExpired:code='TIMEOUT_90s'
  rows.append(dict(name=name,label=label,command=cmd,root=root,exit=code));(out/'runs.json').write_text(json.dumps(rows,indent=2));print('DONE',name,label,code,flush=True)
