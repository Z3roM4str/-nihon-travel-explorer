import subprocess,json,pathlib,os,time
out=pathlib.Path('/workspace/b10-reconciliation-evidence');env=os.environ.copy();env.update(NIHON_CHROMIUM_PATH='/tmp/b10-browsers/chromium-1234/chrome-linux64/chrome',PLAYWRIGHT_BROWSERS_PATH='/tmp/b10-browsers');results=[]
for name,extra,args in [('negative',{'NIHON_B24_MUTANT':'hidden-day-icons'},['--viewport=320x568']),('all-viewports',{},[])]:
 start=time.time(); cmd=['node','scripts/b24-real-input-audit.mjs',*args]
 with (out/('b24-final-'+name+'.txt')).open('w') as log:
  log.write(json.dumps({'cmd':cmd,'extra':extra,'cwd':'/workspace/nihon/app'})+'\n');log.flush();c=subprocess.call(cmd,cwd='/workspace/nihon/app',env={**env,**extra},stdout=log,stderr=subprocess.STDOUT)
 results.append({'name':name,'exit':c,'expectedExit':1 if name=='negative' else 0,'seconds':round(time.time()-start,2)});(out/'b24-final-results.json').write_text(json.dumps(results,indent=2));print(name,c,flush=True)
