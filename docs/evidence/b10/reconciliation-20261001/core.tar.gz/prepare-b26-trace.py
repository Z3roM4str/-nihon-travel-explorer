from pathlib import Path
for root in ['/workspace/nihon/app','/workspace/nihon-main/app']:
 p=Path(root)/'scripts/b26-nosotros-check.mjs';s=p.read_text();a=s.index('  const VIEWPORTS = [',s.index('const browser = await playwright'));b=s.index('\n} finally {',a);s=s[:a]+"  await auditStructureAndIdentity(browser, { width: 390, height: 844 });"+s[b:]
 needle='    await page.keyboard.press("Enter");\n    check("I-RESET-CANCEL",'
 i=s.index(needle)
 s=s[:i]+s[i:].replace('    await page.keyboard.press("Enter");','''    await page.evaluate(()=>{ window.__cancelTrace=[]; for(const event of ['keydown','keyup','click','focusin','focusout']) document.addEventListener(event,e=>window.__cancelTrace.push({event,key:e.key,target:e.target?.getAttribute?.('data-focus-key'),text:e.target?.textContent?.slice(0,60),active:document.activeElement?.getAttribute('data-focus-key'),t:performance.now()}),true); });
    await page.keyboard.press("Enter");''',1)
 old='    check("I-RESET-CANCEL", same(await stored(page), beforeReset) && /Reiniciar/.test((await activeElementInfo(page)).text),'
 new='''    const immediate={unchanged:same(await stored(page),beforeReset),focus:await activeElementInfo(page)};
    check("I-RESET-CANCEL", immediate.unchanged && /Reiniciar/.test(immediate.focus.text),''';assert old in s;s=s.replace(old,new)
 anchor='    await resetBtn.click();\n    await cards(page).nth(1).getByRole("button", { name: "Sí, reiniciar" }).click();'
 diag='''    await page.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));
    console.log("# CANCEL-TRACE "+JSON.stringify({immediate,afterTwoFrames:await activeElementInfo(page),trace:await page.evaluate(()=>window.__cancelTrace)}));
''';assert anchor in s;s=s.replace(anchor,diag+anchor);(Path(root)/'scripts/b26-cancel-trace.mjs').write_text(s)
