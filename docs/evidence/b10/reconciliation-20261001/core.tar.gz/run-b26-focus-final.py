import subprocess,pathlib,json,os,time
out=pathlib.Path('/workspace/b10-reconciliation-evidence');env={**os.environ,'NIHON_BROWSER':'webkit','NIHON_WEBKIT_PATH':'/tmp/b10-webkit','PLAYWRIGHT_BROWSERS_PATH':'/tmp/b10-browsers'};results=[];failed=False
for i in range(1,11):
 for name,root in [('combined','/workspace/nihon/app')]:
  start=time.time()
  with (out/f'focus-final-trace-{name}-{i}.txt').open('w') as log:c=subprocess.call(['node','scripts/b26-cancel-trace.mjs'],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
  results.append({'name':name,'iteration':i,'exit':c,'seconds':round(time.time()-start,2)});(out/'focus-final-trace-results.json').write_text(json.dumps(results,indent=2));print(name,i,c,flush=True)
  if c:failed=True
 if failed:break
