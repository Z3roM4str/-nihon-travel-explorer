import subprocess, pathlib, os, json, time, signal
out=pathlib.Path('/workspace/b10-reconciliation-evidence')
env=os.environ.copy();env.update(PLAYWRIGHT_BROWSERS_PATH='/tmp/b10-browsers',NIHON_CHROMIUM_PATH='/tmp/b10-browsers/chromium-1234/chrome-linux64/chrome',NIHON_WEBKIT_PATH='/tmp/b10-webkit',NIHON_BASE_URL='http://127.0.0.1:4181')
jobs=[('photo-api', 'b10-photo-projection-check.mjs', {}),('b20', 'block20-place-detail-check.mjs', {}),('l1','b10-l1-check.mjs',{'NIHON_B10_OUT':str(out/'final-l1')}),('l2-chromium','b10-l2-check.mjs',{'NIHON_L2_OUT':str(out/'final-l2-chromium')}),('l2-webkit','b10-l2-check.mjs',{'NIHON_BROWSER':'webkit','NIHON_L2_OUT':str(out/'final-l2-webkit')}),('perf-before','b10-performance-check.mjs',{'NIHON_B10_DIST':'/tmp/b10-alerts-before-dist','NIHON_B10_OUT':str(out/'perf-before')}),('perf-after','b10-performance-check.mjs',{'NIHON_B10_OUT':str(out/'perf-after')}),('b27','b27-viaje-dias-check.mjs',{}),('b29','b29-day-order-tools-check.mjs',{})]
for gate in ['b26-nosotros-check.mjs','b30-where-to-sleep-check.mjs','b31-reservas-resumen-check.mjs']:
 for engine in ['chromium','webkit']:jobs.append((gate.split('-')[0]+'-'+engine,gate,{'NIHON_BROWSER':engine}))
results=[]
for name,script,extra in jobs:
 taskenv={**env,**extra};cmd=['node','scripts/'+script];start=time.time()
 with (out/('final-'+name+'.txt')).open('w') as log:
  log.write(json.dumps({'cmd':cmd,'cwd':'/workspace/nihon/app','env':{k:taskenv[k] for k in set(extra)|{'PLAYWRIGHT_BROWSERS_PATH','NIHON_CHROMIUM_PATH','NIHON_WEBKIT_PATH','NIHON_BASE_URL'}}})+'\n');log.flush()
  process=subprocess.Popen(cmd,cwd='/workspace/nihon/app',env=taskenv,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try:code=process.wait(timeout=900)
  except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL);process.wait();code='watchdog-900s'
 results.append({'name':name,'command':cmd,'exit':code,'seconds':round(time.time()-start,2),'codeHead':'9574372','combined':False});(out/'final-independent-results.json').write_text(json.dumps(results,indent=2));print(name,code,flush=True)
