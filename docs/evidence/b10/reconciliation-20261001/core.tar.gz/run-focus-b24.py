import subprocess,os,pathlib,json,time,shutil
out=pathlib.Path('/workspace/b10-reconciliation-evidence');env={**os.environ,'NIHON_CHROMIUM_PATH':'/tmp/b10-browsers/chromium-1234/chrome-linux64/chrome','PLAYWRIGHT_BROWSERS_PATH':'/tmp/b10-browsers'};cmd=['node','scripts/b24-real-input-audit.mjs'];start=time.time()
with (out/'focus-final-b24.txt').open('w') as log:
 log.write(json.dumps({'cmd':cmd,'cwd':'/workspace/nihon/app','codeTree':'5e958067575c123cc8363a598aedff7e543b7d6b','environment':{k:v for k,v in env.items() if k.startswith(('NIHON','PLAYWRIGHT'))}})+'\n');log.flush();c=subprocess.call(cmd,cwd='/workspace/nihon/app',env=env,stdout=log,stderr=subprocess.STDOUT)
(out/'focus-final-b24-results.json').write_text(json.dumps({'exit':c,'seconds':round(time.time()-start,2)},indent=2));shutil.copytree('/tmp/b24',out/'focus-final-b24-screenshots',dirs_exist_ok=False);print('b24',c,flush=True)
