import subprocess,pathlib,json,time,os,signal
out=pathlib.Path('/workspace/b10-reconciliation-evidence'); env=os.environ.copy();env.update(PLAYWRIGHT_BROWSERS_PATH='/tmp/b10-browsers',NIHON_CHROMIUM_PATH='/tmp/b10-browsers/chromium-1234/chrome-linux64/chrome',NIHON_WEBKIT_PATH='/tmp/b10-webkit',NIHON_BROWSER='chromium')
jobs=[]
for n in range(1,4):
 for label,cwd in [('main','/workspace/nihon-main/app'),('combined','/workspace/nihon/app')]:jobs.append((f'perf-{label}-{n}',cwd,['node','scripts/b10-performance-diagnostic.mjs'],{}))
for label,cwd,port in [('main','/workspace/nihon-main/app',4182),('combined','/workspace/nihon/app',4181)]:
 for script in ['b25-quiero-ir-check.mjs', 'b18-cloud-diagnostic.mjs' if label=='main' else 'b18-regression-check.mjs']:jobs.append((f'{script}-{label}',cwd,['node','scripts/'+script],{'NIHON_BASE_URL':f'http://127.0.0.1:{port}'}))
results=[]
for name,cwd,cmd,extra in jobs:
 start=time.time()
 with (out/('paired-'+name+'.txt')).open('w') as log:
  log.write(json.dumps({'cwd':cwd,'cmd':cmd,'env':{k:v for k,v in {**env,**extra}.items() if k.startswith(('NIHON_','PLAYWRIGHT_'))}})+'\n');log.flush();p=subprocess.Popen(cmd,cwd=cwd,env={**env,**extra},stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try:c=p.wait(timeout=900)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait();c='watchdog-900s'
 results.append({'name':name,'exit':c,'seconds':round(time.time()-start,2)});(out/'paired-results.json').write_text(json.dumps(results,indent=2));print(name,c,flush=True)
