import pathlib,tarfile,json,hashlib
src=pathlib.Path('/workspace/b10-reconciliation-evidence');dest=pathlib.Path('/workspace/nihon/docs/evidence/b10/reconciliation-20261001');dest.mkdir(parents=True,exist_ok=True)
files=sorted(src.rglob('*.png'));groups=[];current=[];size=0
for p in files:
 n=p.stat().st_size
 if current and size+n>1800000:groups.append(current);current=[];size=0
 current.append(p);size+=n
if current:groups.append(current)
rows=[]
for i,group in enumerate(groups,1):
 p=dest/f'visual-{i:02d}.tar.gz'
 with tarfile.open(p,'w:gz') as t:
  for f in group:t.add(f,arcname=str(f.relative_to(src)),recursive=False)
 b=p.read_bytes();rows.append({'path':str(p.relative_to('/workspace/nihon')),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'members':[str(f.relative_to(src)) for f in group]})
(src/'visual-packages.json').write_text(json.dumps(rows,indent=2));print([(r['path'],r['bytes'],len(r['members'])) for r in rows])
