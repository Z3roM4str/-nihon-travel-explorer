# Revisión React de la combinación

Skill: vercel:react-best-practices, c7/react-best-practices, leído al cerrar la reconciliación. Código de producto idéntico al probado desde 51a0d75; commits posteriores sólo runners.

- App: estado discriminado nacional/hub conserva exclusión mutua; scroll/foco nacional usa ref transitoria y useLayoutEffect con dependencia primitiva, sin estado derivado redundante. Devuelve foco a botón conectado con preventScroll. No modifica filtros/persistencia.
- Sheet: refs DOM tipadas, effect de teclado con cleanup, enfoque inicial/retorno y exclusión de contenido oculto; estilos en dueño y aria-labelledby conservado. No se retira Tab.
- Gallery: reduced motion consultado antes de scrollTo, efecto de lightbox conserva opener conectado y listeners con cleanup; no carga fuentes/fotografías externas ni pierde slides/API.
- FilterPanel/L2: valores derivados existentes, sin duplicar stores ni cambiar modelo; handlers/acciones conservados.
- App chunk boundaries: se mantienen las dos superficies lazy/prefetch, sin dependencia nueva ni waterfall añadido. Leaflet sigue siendo una causa de peso identificada, pero convertir los dos árboles de mapas a nuevos límites de carga queda como propuesta de mayor alcance, no refactor silencioso.
- Datos: proyecciones build-time; resolución pública síncrona y API comprobadas exhaustivamente; no serialización ni borrado runtime de registros.

No hallazgos nuevos que justifiquen refactor adicional tras la regresión. Evidencia funcional/teclado/visual en resultados nuevos; esta revisión no certifica Safari físico o accesibilidad exhaustiva.
