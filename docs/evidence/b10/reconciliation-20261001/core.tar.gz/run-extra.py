import subprocess,pathlib,json,os,time,signal
out=pathlib.Path('/workspace/b10-reconciliation-evidence'); cwd='/workspace/nihon/app'; base=os.environ.copy();base.update(PLAYWRIGHT_BROWSERS_PATH='/tmp/b10-browsers',NIHON_CHROMIUM_PATH='/tmp/b10-browsers/chromium-1234/chrome-linux64/chrome',NIHON_WEBKIT_PATH='/tmp/b10-webkit',NIHON_BASE_URL='http://127.0.0.1:4181')
inv=['src/components/OrderedSequenceBuilder.stable-day-identity.test.ts','src/lib/zone-plan-link.test.ts','src/lib/accommodation-zone.test.ts','src/lib/planning-draft-v8.test.ts','src/components/OrderedSequenceBuilder.inter-hub.test.ts','src/lib/inter-hub-segment.test.ts','src/lib/zone-accommodation-choice.test.ts','src/lib/planning-draft-v8.reorder.test.ts','src/lib/zone-journey-context.test.ts']
jobs=[('invariants',['npm','test','--',*inv],{}) ,('b28-isolated',['node','scripts/b28-reorder-dnd-check.mjs'],{}),('motion-surfaces-chromium-retry',['node','scripts/b10-motion-surfaces-check.mjs'],{'NIHON_BROWSER':'chromium','NIHON_B10_OUT':str(out/'combined-motion-surfaces-chromium-retry')}),('microcopy-webkit-retry',['node','scripts/b10-microcopy-check.mjs'],{'NIHON_BROWSER':'webkit'}),('cold-warm',['node','scripts/b10-performance-surfaces-check.mjs'],{'NIHON_B10_OUT':str(out/'combined-cold-warm')})]
for e in ['chromium','webkit']:jobs.append(('alerts-'+e,['node','scripts/b10-alerts-extraction-check.mjs'],{'NIHON_BROWSER':e,'NIHON_CHROMIUM_PATH':'/usr/bin/chromium','NIHON_B10_OUT':str(out/('combined-alerts-'+e)),'NIHON_B10_COMPARE':str(out/('alerts-after-'+e)/'results.json')}))
for v in ['desktop','mobile']:jobs.append(('phase5a-'+v,['node','scripts/phase5a-rc-browser-audit.mjs','--viewport='+v],{}))
results=[]
for name,cmd,extra in jobs:
 env={**base,**extra}; start=time.time()
 with (out/('extra-'+name+'.txt')).open('w') as log:
  head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=cwd,text=True).strip();log.write(json.dumps({'command':cmd,'cwd':cwd,'env':{k:v for k,v in env.items() if k.startswith(('NIHON_','PLAYWRIGHT_'))},'head':head})+'\n');log.flush();p=subprocess.Popen(cmd,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try:c=p.wait(timeout=900)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait();c='watchdog-900s'
 results.append({'name':name,'exit':c,'head':head,'seconds':round(time.time()-start,2)});(out/'extra-results.json').write_text(json.dumps(results,indent=2));print(name,c,flush=True)
