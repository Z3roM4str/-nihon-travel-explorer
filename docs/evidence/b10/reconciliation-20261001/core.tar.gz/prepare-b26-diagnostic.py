from pathlib import Path
for root in ['/workspace/nihon/app','/workspace/nihon-main/app']:
 p=Path(root)/'scripts/b26-nosotros-check.mjs';s=p.read_text();a=s.index('  const VIEWPORTS = [',s.index('const browser = await playwright'));b=s.index('\n} finally {',a);s=s[:a]+"  await auditStructureAndIdentity(browser, { width: 390, height: 844 });"+s[b:]
 old='    check("I-RESET-CANCEL", same(await stored(page), beforeReset) && /Reiniciar/.test((await activeElementInfo(page)).text),'
 new='''    const cancelImmediate = {unchanged:same(await stored(page),beforeReset),focus:await activeElementInfo(page)};
    await page.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));
    console.log("# CANCEL-DIAGNOSTIC "+JSON.stringify({immediate:cancelImmediate,afterTwoFrames:await activeElementInfo(page)}));
    check("I-RESET-CANCEL", cancelImmediate.unchanged && /Reiniciar/.test(cancelImmediate.focus.text),'''
 assert old in s;s=s.replace(old,new);(Path(root)/'scripts/b26-cancel-diagnostic.mjs').write_text(s)
