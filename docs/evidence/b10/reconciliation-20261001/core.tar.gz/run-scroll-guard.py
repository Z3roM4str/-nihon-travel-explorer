import os,pathlib,json,subprocess,time
out=pathlib.Path('/workspace/b10-reconciliation-evidence');env={**os.environ,'NIHON_WEBKIT_PATH':'/tmp/b10-webkit','NIHON_CHROMIUM_PATH':'/tmp/b10-browsers/chromium-1234/chrome-linux64/chrome','PLAYWRIGHT_BROWSERS_PATH':'/tmp/b10-browsers'};results=[]
for name,extra in [('negative',{'NIHON_BROWSER':'chromium','NIHON_SCROLL_MUTANT':'contained'}),('chromium',{'NIHON_BROWSER':'chromium'}),('webkit',{'NIHON_BROWSER':'webkit'})]:
 start=time.time();e={**env,**extra,'NIHON_B10_OUT':str(out/('scroll-guard-2-'+name))}
 with (out/('scroll-guard-2-'+name+'.txt')).open('w') as log:c=subprocess.call(['node','scripts/b10-embedded-scroll-check.mjs'],cwd='/workspace/nihon/app',env=e,stdout=log,stderr=subprocess.STDOUT)
 results.append({'name':name,'exit':c,'seconds':round(time.time()-start,2)});(out/'scroll-guard-2-results.json').write_text(json.dumps(results,indent=2));print(name,c,flush=True)
