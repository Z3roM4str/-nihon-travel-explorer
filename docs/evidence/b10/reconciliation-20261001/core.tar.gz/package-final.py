import pathlib,tarfile,json,hashlib
root=pathlib.Path('/workspace/b10-reconciliation-evidence');dest=pathlib.Path('/workspace/nihon/docs/evidence/b10/reconciliation-20261001');old={m for r in json.load(open(root/'visual-packages.json')) for m in r['members']};files=[p for p in root.rglob('*.png') if str(p.relative_to(root)) not in old];out=[];groups=[];batch=[];size=0
for p in sorted(files):
 if size+p.stat().st_size>2200000 and batch:groups.append(batch);batch=[];size=0
 batch.append(p);size+=p.stat().st_size
if batch:groups.append(batch)
for n,group in enumerate(groups,14):
 p=dest/f'visual-{n:02}.tar.gz'
 with tarfile.open(p,'w:gz') as tar:
  for f in group:tar.add(f,arcname=str(f.relative_to(root)))
 out.append({'path':str(p.relative_to('/workspace/nihon')),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'members':[str(f.relative_to(root)) for f in group]})
(root/'visual-final-packages.json').write_text(json.dumps(out,indent=2));print(len(files),'new images',len(groups),'archives',sum(r['bytes'] for r in out))
