import subprocess,pathlib,os,json,time,signal
out=pathlib.Path('/workspace/b10-reconciliation-evidence');env=os.environ.copy();env.update(PLAYWRIGHT_BROWSERS_PATH='/tmp/b10-browsers',NIHON_CHROMIUM_PATH='/tmp/b10-browsers/chromium-1234/chrome-linux64/chrome',NIHON_WEBKIT_PATH='/tmp/b10-webkit',NIHON_BASE_URL='http://127.0.0.1:4181')
cwd='/workspace/nihon/app';head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=cwd,text=True).strip();jobs=[('lint',['npm','run','lint'],{}),('vitest',['npm','test','--','--reporter=basic'],{}),('invariants',['npm','test','--','src/components/OrderedSequenceBuilder.stable-day-identity.test.ts','src/lib/zone-plan-link.test.ts','src/lib/accommodation-zone.test.ts','src/lib/planning-draft-v8.test.ts','src/components/OrderedSequenceBuilder.inter-hub.test.ts','src/lib/inter-hub-segment.test.ts','src/lib/zone-accommodation-choice.test.ts','src/lib/planning-draft-v8.reorder.test.ts','src/lib/zone-journey-context.test.ts'],{}),('photo-api',['node','scripts/b10-photo-projection-check.mjs'],{}),('walking-api',['node','scripts/b10-walking-projection-check.mjs'],{}),('l1',['node','scripts/b10-l1-check.mjs'],{'NIHON_B10_OUT':str(out/'scroll-final-l1')})]
for kind in ['motion','a11y','gallery-motion','national-map','l2','performance']:
 for engine in ['chromium','webkit']:
  extra={'NIHON_BROWSER':engine,'NIHON_B10_OUT':str(out/f'scroll-final-{kind}-{engine}'),'NIHON_L2_OUT':str(out/f'scroll-final-{kind}-{engine}'),'NIHON_B10_PERF_JSON':str(out/f'scroll-final-perf-{engine}.json')}
  jobs.append((kind+'-'+engine,['node',f'scripts/b10-{kind}-check.mjs'],extra))
for script in ['b26-nosotros-check.mjs','b30-where-to-sleep-check.mjs','b31-reservas-resumen-check.mjs']:
 for engine in ['chromium','webkit']:jobs.append((script.removesuffix('.mjs')+'-'+engine,['node','scripts/'+script],{'NIHON_BROWSER':engine}))
for script in ['b27-viaje-dias-check.mjs','b29-day-order-tools-check.mjs','b28-reorder-dnd-check.mjs','b18-browser-back-check.mjs','b18-regression-check.mjs','b25-quiero-ir-check.mjs','block1-ux-browser-audit.mjs','block13-portable-backup-browser-audit.mjs','block14-release-readiness-browser-audit.mjs','b24-real-input-audit.mjs']:
 args=['--browser='+env['NIHON_CHROMIUM_PATH']] if script.startswith(('block1-','block13-','block14-')) else []
 jobs.append((script.removesuffix('.mjs'),['node','scripts/'+script,*args],{}))
for mutant in ['hidden-day-icons','blocked-embedded-scroll']:jobs.append(('b24-negative-'+mutant,['node','scripts/b24-real-input-audit.mjs','--viewport=320x568'],{'NIHON_B24_MUTANT':mutant}))
for v in ['desktop','mobile']:jobs.append(('phase5a-'+v,['node','scripts/phase5a-rc-browser-audit.mjs','--viewport='+v],{}))
results=[]
for name,cmd,extra in jobs:
 taskenv={**env,**extra};start=time.time()
 with (out/('scroll-final-'+name+'.txt')).open('w') as log:
  log.write(json.dumps({'cmd':cmd,'cwd':cwd,'env':{k:taskenv[k] for k in set(extra)|{'PLAYWRIGHT_BROWSERS_PATH','NIHON_CHROMIUM_PATH','NIHON_WEBKIT_PATH','NIHON_BASE_URL'}},'codeHead':head})+'\n');log.flush();p=subprocess.Popen(cmd,cwd=cwd,env=taskenv,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try:code=p.wait(timeout=900)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait();code='watchdog-900s'
 results.append({'name':name,'command':cmd,'exit':code,'seconds':round(time.time()-start,2),'codeHead':head});(out/'scroll-final-results.json').write_text(json.dumps(results,indent=2));print(name,code,flush=True)
