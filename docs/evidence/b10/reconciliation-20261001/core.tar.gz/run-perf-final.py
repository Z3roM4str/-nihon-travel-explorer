import pathlib,os,subprocess,json,time
out=pathlib.Path('/workspace/b10-reconciliation-evidence');base=os.environ.copy();base.update(NIHON_CHROMIUM_PATH='/tmp/b10-browsers/chromium-1234/chrome-linux64/chrome',NIHON_WEBKIT_PATH='/tmp/b10-webkit',PLAYWRIGHT_BROWSERS_PATH='/tmp/b10-browsers');results=[]
for name,extra in [('negative',{'NIHON_BROWSER':'chromium','NIHON_B10_PERF_MUTANT':'eager-far-card'}),('chromium',{'NIHON_BROWSER':'chromium'}),('webkit',{'NIHON_BROWSER':'webkit'})]:
 cmd=['node','scripts/b10-performance-check.mjs']; env={**base,**extra,'NIHON_B10_PERF_JSON':str(out/f'perf-final-{name}.json')};start=time.time()
 with (out/f'perf-final-{name}.txt').open('w') as log:
  log.write(json.dumps({'cmd':cmd,'cwd':'/workspace/nihon/app','env':{k:v for k,v in env.items() if k.startswith(('NIHON_','PLAYWRIGHT_'))}})+'\n');log.flush();c=subprocess.call(cmd,cwd='/workspace/nihon/app',env=env,stdout=log,stderr=subprocess.STDOUT)
 d=json.load(open(env['NIHON_B10_PERF_JSON']));expected=(len(d['failures'])==2 and any('imágenes nuevas' in f for f in d['failures']) and d['hubs'][0]['newFarLoadedAtOpen']>0) if name=='negative' else len(d['failures'])==1 and d['failures'][0].startswith('[J01]')
 results.append({'name':name,'exit':c,'expectedOnlyG6OrNegativeDetected':expected,'seconds':round(time.time()-start,2)});(out/'perf-final-results.json').write_text(json.dumps(results,indent=2));print(name,c,expected,flush=True)
