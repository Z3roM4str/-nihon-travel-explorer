import pathlib,subprocess,os,json,time
out=pathlib.Path('/workspace/b10-reconciliation-evidence'); env={**os.environ,'NIHON_CHROMIUM_PATH':'/tmp/b10-browsers/chromium-1234/chrome-linux64/chrome','NIHON_WEBKIT_PATH':'/tmp/b10-webkit','PLAYWRIGHT_BROWSERS_PATH':'/tmp/b10-browsers','NIHON_BASE_URL':'http://127.0.0.1:4181'}; jobs=[('lint',['npm','run','lint'],{}),('vitest',['npm','test','--','--reporter=basic'],{}),('bundle',['node','scripts/bundle-report.mjs','--json'],{})]
for script in ['b26-nosotros-check.mjs','b30-where-to-sleep-check.mjs','b31-reservas-resumen-check.mjs','b10-a11y-check.mjs','b10-performance-check.mjs']:
 for engine in ['chromium','webkit']:jobs.append((script[:-4]+'-'+engine,['node','scripts/'+script],{'NIHON_BROWSER':engine,'NIHON_B10_OUT':str(out/('focus-'+script[:-4]+'-'+engine)),'NIHON_B10_PERF_JSON':str(out/('focus-perf-'+engine+'.json'))}))
for script in ['block1-ux-browser-audit.mjs','block13-portable-backup-browser-audit.mjs','block14-release-readiness-browser-audit.mjs','b18-browser-back-check.mjs','b18-regression-check.mjs']:
 args=['--browser='+env['NIHON_CHROMIUM_PATH']] if script.startswith('block') else []
 jobs.append((script[:-4],['node','scripts/'+script,*args],{}))
results=[]
for name,cmd,extra in jobs:
 start=time.time()
 with (out/('focus-final-'+name+'.txt')).open('w') as log:
  log.write(json.dumps({'cmd':cmd,'cwd':'/workspace/nihon/app','env':{k:v for k,v in {**env,**extra}.items() if k.startswith(('NIHON','PLAYWRIGHT'))}})+'\n');log.flush();c=subprocess.call(cmd,cwd='/workspace/nihon/app',env={**env,**extra},stdout=log,stderr=subprocess.STDOUT)
 results.append({'name':name,'exit':c,'seconds':round(time.time()-start,2)});(out/'focus-final-results.json').write_text(json.dumps(results,indent=2));print(name,c,flush=True)
