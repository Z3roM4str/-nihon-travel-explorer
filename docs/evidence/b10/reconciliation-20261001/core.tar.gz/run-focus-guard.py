import os,subprocess,pathlib,json,time
out=pathlib.Path('/workspace/b10-reconciliation-evidence');env={**os.environ,'NIHON_CHROMIUM_PATH':'/tmp/b10-browsers/chromium-1234/chrome-linux64/chrome','NIHON_WEBKIT_PATH':'/tmp/b10-webkit','PLAYWRIGHT_BROWSERS_PATH':'/tmp/b10-browsers'};results=[]
for name,extra in [('negative',{'NIHON_BROWSER':'webkit','NIHON_B10_FOCUS_MUTANT':'blocked-restoration'}),('chromium',{'NIHON_BROWSER':'chromium'}),('webkit',{'NIHON_BROWSER':'webkit'})]:
 start=time.time()
 with (out/('focus-guard-'+name+'.txt')).open('w') as log:c=subprocess.call(['node','scripts/b10-traveller-focus-check.mjs'],cwd='/workspace/nihon/app',env={**env,**extra},stdout=log,stderr=subprocess.STDOUT)
 results.append({'name':name,'exit':c,'seconds':round(time.time()-start,2)});(out/'focus-guard-results.json').write_text(json.dumps(results,indent=2));print(name,c,flush=True)
