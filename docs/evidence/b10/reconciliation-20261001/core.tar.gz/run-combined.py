import subprocess,pathlib,os,json,time,signal
out=pathlib.Path('/workspace/b10-reconciliation-evidence');env=os.environ.copy();env.update(PLAYWRIGHT_BROWSERS_PATH='/tmp/b10-browsers',NIHON_CHROMIUM_PATH='/tmp/b10-browsers/chromium-1234/chrome-linux64/chrome',NIHON_WEBKIT_PATH='/tmp/b10-webkit',NIHON_BASE_URL='http://127.0.0.1:4181')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd='/workspace/nihon',text=True).strip();tree=subprocess.check_output(['git','rev-parse','HEAD:app'],cwd='/workspace/nihon',text=True).strip()
jobs=[('lint',['npm','run','lint'],{}),('photo-api',['node','scripts/b10-photo-projection-check.mjs'],{}),('walking-api',['node','scripts/b10-walking-projection-check.mjs'],{}),('l1',['node','scripts/b10-l1-check.mjs'],{'NIHON_B10_OUT':str(out/'combined-l1')})]
for kind in ['motion','motion-surfaces','a11y','gallery-motion','national-map','l2','performance']:
 for engine in ['chromium','webkit']:
  extra={'NIHON_BROWSER':engine,'NIHON_B10_OUT':str(out/f'combined-{kind}-{engine}'),'NIHON_L2_OUT':str(out/f'combined-{kind}-{engine}')}
  jobs.append((kind+'-'+engine,['node',f'scripts/b10-{kind}-check.mjs'],extra))
for script in ['b10-microcopy-check.mjs','d0b-design-system-hygiene-check.mjs','d5-normative-vocabulary-check.mjs','b26-nosotros-check.mjs','b30-where-to-sleep-check.mjs','b31-reservas-resumen-check.mjs']:
 for engine in ['chromium','webkit']:jobs.append((script.removesuffix('.mjs')+'-'+engine,['node','scripts/'+script],{'NIHON_BROWSER':engine}))
for script in ['b27-viaje-dias-check.mjs','b29-day-order-tools-check.mjs','b28-day-reorder-check.mjs','b25-quiero-ir-check.mjs','b18-chrome-check.mjs','b18-a11y-check.mjs','b18-responsive-check.mjs','b18-viaje-lugar-check.mjs','b18-browser-back-check.mjs','b18-regression-check.mjs','block19-discovery-browser-audit.mjs','block19-grid-check.mjs','block19-contrast-check.mjs','block20-place-detail-check.mjs','b21-global-search-browser-audit.mjs','block12-bundle-architecture-browser-audit.mjs','ddr03-persistence-check.mjs','block1-ux-browser-audit.mjs','block13-portable-backup-browser-audit.mjs','block14-release-readiness-browser-audit.mjs','b24-real-input-audit.mjs']:
 args=['--browser='+env['NIHON_CHROMIUM_PATH']] if script.startswith(('block1-','block12-','block13-','block14-')) else []
 jobs.append((script.removesuffix('.mjs'),['node','scripts/'+script,*args],{}))
results=[]
for name,cmd,extra in jobs:
 if not pathlib.Path('/workspace/nihon/app/'+cmd[-1]).exists() and len(cmd)>1 and cmd[0]=='node' and not pathlib.Path('/workspace/nihon/app/'+cmd[1]).exists():
  results.append({'name':name,'exit':'missing-runner','cmd':cmd});continue
 taskenv={**env,**extra};start=time.time()
 with (out/('combined-'+name+'.txt')).open('w') as log:
  log.write(json.dumps({'cmd':cmd,'cwd':'/workspace/nihon/app','env':{k:taskenv[k] for k in set(extra)|{'PLAYWRIGHT_BROWSERS_PATH','NIHON_CHROMIUM_PATH','NIHON_WEBKIT_PATH','NIHON_BASE_URL'}}})+'\n');log.flush()
  process=subprocess.Popen(cmd,cwd='/workspace/nihon/app',env=taskenv,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try:code=process.wait(timeout=900)
  except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL);process.wait();code='watchdog-900s'
 results.append({'name':name,'command':cmd,'exit':code,'seconds':round(time.time()-start,2),'codeHead':head,'appTree':tree,'combined':True});(out/'combined-results.json').write_text(json.dumps(results,indent=2));print(name,code,flush=True)
