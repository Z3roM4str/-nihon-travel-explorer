import subprocess,pathlib,json,os,time,signal
out=pathlib.Path('/workspace/b10-reconciliation-evidence');env={**os.environ,'NIHON_WEBKIT_PATH':'/tmp/b10-webkit','NIHON_CHROMIUM_PATH':'/tmp/b10-browsers/chromium-1234/chrome-linux64/chrome','PLAYWRIGHT_BROWSERS_PATH':'/tmp/b10-browsers'};cwd='/workspace/nihon/app';jobs=[('typecheck',cwd,['npm','exec','tsc','--','-b'],{}),('vitest',cwd,['npm','test','--','--reporter=basic'],{})]
for engine in ['chromium','webkit']:
 for viewport in ['mobile','desktop']:jobs.append((f'b21-{engine}-{viewport}',cwd,['node','scripts/b21-global-search-browser-audit.mjs','--viewport='+viewport],{'NIHON_BROWSER':engine}))
jobs.append(('b21-negative',cwd,['node','scripts/b21-negative-restore.mjs'],{'NIHON_BROWSER':'chromium'}))
for label,root in [('main','/workspace/nihon-main/app'),('combined-1',cwd),('combined-2',cwd)]:jobs.append(('b26-webkit-'+label,root,['node','scripts/b26-nosotros-check.mjs'],{'NIHON_BROWSER':'webkit'}))
results=[]
for name,root,cmd,extra in jobs:
 start=time.time()
 with (out/('late-final-'+name+'.txt')).open('w') as log:
  log.write(json.dumps({'cmd':cmd,'cwd':root,'extra':extra})+'\n');log.flush();p=subprocess.Popen(cmd,cwd=root,env={**env,**extra},stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try:c=p.wait(timeout=900)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait();c='watchdog-900s'
 results.append({'name':name,'exit':c,'seconds':round(time.time()-start,2)});(out/'late-final-results.json').write_text(json.dumps(results,indent=2));print(name,c,flush=True)
