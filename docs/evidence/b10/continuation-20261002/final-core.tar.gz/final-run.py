import subprocess,pathlib,os,json,time,signal
out=pathlib.Path('/workspace/b10-work/final');out.mkdir(exist_ok=True);env=os.environ.copy();env.update(PLAYWRIGHT_BROWSERS_PATH='/workspace/b10-work/browsers',NIHON_CHROMIUM_PATH='/usr/bin/chromium',NIHON_WEBKIT_PATH='/workspace/b10-work/webkit',NIHON_BASE_URL='http://127.0.0.1:4181')
cwd='/workspace/nihon/app';head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=cwd,text=True).strip();tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=cwd,text=True).strip()
jobs=[('lint',['npm','run','lint'],{}),('vitest',['npm','test','--','--reporter=json','--outputFile=/workspace/b10-work/final/vitest.json'],{}),('invariants',['npm','test','--','src/components/OrderedSequenceBuilder.stable-day-identity.test.ts','src/lib/zone-plan-link.test.ts','src/lib/accommodation-zone.test.ts','src/lib/planning-draft-v8.test.ts','src/components/OrderedSequenceBuilder.inter-hub.test.ts','src/lib/inter-hub-segment.test.ts','src/lib/zone-accommodation-choice.test.ts','src/lib/planning-draft-v8.reorder.test.ts','src/lib/zone-journey-context.test.ts'],{}),('evidence-options',['node','scripts/evidence-options-check.mjs'],{}),('photo-api',['node','scripts/b10-photo-projection-check.mjs'],{}),('walking-api',['node','scripts/b10-walking-projection-check.mjs'],{}),('l1',['node','scripts/b10-l1-check.mjs'],{'NIHON_B10_OUT':str(out/'l1')})]
for kind in ['motion','a11y','gallery-motion','national-map','l2','performance','embedded-scroll','traveller-focus','collections-keyboard']:
 for engine in ['chromium','webkit']:
  extra={'NIHON_BROWSER':engine,'NIHON_B10_OUT':str(out/f'{kind}-{engine}'),'NIHON_L2_OUT':str(out/f'{kind}-{engine}'),'NIHON_B10_PERF_JSON':str(out/f'perf-{engine}.json')}
  jobs.append((kind+'-'+engine,['node',f'scripts/b10-{kind}-check.mjs'],extra))
for script in ['b26-nosotros-check.mjs','b30-where-to-sleep-check.mjs','b31-reservas-resumen-check.mjs','d0b-design-system-hygiene-check.mjs']:
 for engine in ['chromium','webkit']:jobs.append((script.removesuffix('.mjs')+'-'+engine,['node','scripts/'+script],{'NIHON_BROWSER':engine}))
for script in ['b27-viaje-dias-check.mjs','b29-day-order-tools-check.mjs','b28-reorder-dnd-check.mjs','b18-browser-back-check.mjs','b18-regression-check.mjs','b25-quiero-ir-check.mjs','block1-ux-browser-audit.mjs','block13-portable-backup-browser-audit.mjs','block14-release-readiness-browser-audit.mjs','b24-real-input-audit.mjs']:
 args=['--browser='+env['NIHON_CHROMIUM_PATH']] if script.startswith(('block1-','block13-','block14-')) else []
 jobs.append((script.removesuffix('.mjs'),['node','scripts/'+script,*args],{}))
for engine in ['chromium','webkit']:
 for kind,var,val in [('scroll','NIHON_SCROLL_MUTANT','contained'),('focus','NIHON_B10_FOCUS_MUTANT','blocked-restoration')]:
  script='b10-embedded-scroll-check.mjs'if kind=='scroll'else'b10-traveller-focus-check.mjs'
  jobs.append((f'negative-{kind}-{engine}',['node','scripts/'+script],{'NIHON_BROWSER':engine,'NIHON_B10_OUT':str(out/f'negative-{kind}-{engine}'),var:val}))
jobs.append(('negative-eager',['node','scripts/b10-performance-check.mjs'],{'NIHON_B10_PERF_MUTANT':'eager-far-card','NIHON_B10_PERF_JSON':str(out/'negative-eager.json')}))
jobs.append(('negative-hidden-icons',['node','scripts/b24-real-input-audit.mjs','--viewport=320x568'],{'NIHON_B24_MUTANT':'hidden-day-icons'}))
for v in ['desktop','mobile']:jobs.append(('phase5a-'+v,['node','scripts/phase5a-rc-browser-audit.mjs','--viewport='+v],{}))
results=[]
for name,cmd,extra in jobs:
 taskenv={**env,**extra};start=time.time()
 with(out/(name+'.log')).open('w')as log:
  log.write(json.dumps({'cmd':cmd,'cwd':cwd,'env':{k:taskenv[k]for k in set(extra)|{'PLAYWRIGHT_BROWSERS_PATH','NIHON_CHROMIUM_PATH','NIHON_WEBKIT_PATH','NIHON_BASE_URL'}},'codeHead':head,'codeTree':tree})+'\n');log.flush();p=subprocess.Popen(cmd,cwd=cwd,env=taskenv,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try:code=p.wait(timeout=900)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait();code='watchdog-900s'
 results.append({'name':name,'command':cmd,'exit':code,'negativeExpected':name.startswith('negative-'),'seconds':round(time.time()-start,2),'codeHead':head,'codeTree':tree});(out/'results.json').write_text(json.dumps(results,indent=2));print(name,code,flush=True)
