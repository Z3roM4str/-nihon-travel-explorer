import sys,tarfile,pathlib,hashlib,json
work=pathlib.Path('/workspace/b10-work');repo=pathlib.Path('/workspace/nihon');label=sys.argv[1];dest=repo/'docs/evidence/b10/continuation-20261002';dest.mkdir(parents=True,exist_ok=True);out=dest/(label+'.tar.gz');rows=[]
files=[]
for item in sys.argv[2:]:
 p=work/item;files.extend(p.rglob('*')if p.is_dir()else[p])
with tarfile.open(out,'w:gz')as t:
 for p in sorted(set(files)):
  if not p.is_file()or p.is_symlink():continue
  b=p.read_bytes();name=str(p.relative_to(work));rows.append({'path':name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()});t.add(p,arcname=name)
b=out.read_bytes();rec={'path':str(out.relative_to(repo)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(),'entries':rows};(dest/(label+'.json')).write_text(json.dumps(rec,indent=2));print(out,len(b),len(rows))

# MCP body limit is 16 MiB; base64 parts stay below it, with archive identity retained.
if len(b)>8*1024*1024:
 import shutil
 local=work/'archives';local.mkdir(exist_ok=True);shutil.copyfile(out,local/out.name);parts=[]
 for i,start in enumerate(range(0,len(b),8*1024*1024)):
  chunk=b[start:start+8*1024*1024];part=out.with_name(out.name+f'.part{i:03d}');part.write_bytes(chunk);parts.append({'path':str(part.relative_to(repo)),'bytes':len(chunk),'sha256':hashlib.sha256(chunk).hexdigest(),'blob':hashlib.sha1(b'blob '+str(len(chunk)).encode()+b'\0'+chunk).hexdigest()})
 rec.update(storage='concatenate parts in listed order, validate archive SHA256, then extract',parts=parts);(dest/(label+'.json')).write_text(json.dumps(rec,indent=2));out.unlink();print('parts',len(parts))
