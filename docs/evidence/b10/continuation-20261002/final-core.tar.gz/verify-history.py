import hashlib,json,pathlib,subprocess,tarfile
root=pathlib.Path('/workspace/nihon');out=pathlib.Path('/workspace/b10-work/history'); rows=[]
def check(manifest,path,expected,data,kind='file'):
 actual=hashlib.sha256(data).hexdigest();blob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest();rows.append({'manifest':manifest,'path':path,'kind':kind,'sha256':actual,'bytes':len(data),'gitBlob':blob,'ok':actual==expected['sha256'] and (expected.get('bytes',len(data))==len(data)) and (expected.get('blob',blob)==blob)})
for label in ['L1','L2','AUTONOMOUS','RECONCILIATION']:
 name=f'docs/B10_{label}_EVIDENCE.json';d=json.loads((root/name).read_text()); artifacts=d['artifacts']; entries=([{'path':k,**v} for k,v in artifacts.items()] if isinstance(artifacts,dict) else artifacts)
 archive={}
 if label=='AUTONOMOUS':
  for f in (root/'docs/evidence/b10/autonomous').rglob('*.tar.gz'):
   with tarfile.open(f) as t:
    for m in t:
     if m.isfile(): archive[m.name]=t.extractfile(m).read()
 for e in entries:
  p=e['path'];p='docs/'+p if p.startswith('evidence/') else p
  if (root/p).exists():data=(root/p).read_bytes()
  else:data=archive[p]
  check(name,p,e,data)
  for key in ['entries','members']:
   if e.get(key) and isinstance(e[key][0],dict):
    with tarfile.open(root/p) as t:
     for m in e[key]:check(name,p+'::'+m['path'],m,t.extractfile(m['path']).read(),'tar member')
 if label=='RECONCILIATION':
  for e in d['appInputs']:check(name,e['path'],e,subprocess.check_output(['git','show','23e112f:'+e['path']],cwd=root),'initial app fingerprint input')
manifest=[]
for name in subprocess.check_output(['git','ls-tree','-r','--name-only','23e112f','docs'],cwd=root,text=True).splitlines():
 if not (name.startswith('docs/B10_') and name.endswith('EVIDENCE.json')):continue
 p=root/name
 data=p.read_bytes();original=subprocess.check_output(['git','show','23e112f:'+str(p.relative_to(root))],cwd=root);manifest.append({'path':str(p.relative_to(root)),'sha256':hashlib.sha256(data).hexdigest(),'unchanged':data==original})
(out/'integrity-new.json').write_text(json.dumps({'records':rows,'manifests':manifest,'failures':sum(not x['ok'] for x in rows)},indent=2));print('records',len(rows),'failures',sum(not x['ok'] for x in rows),'manifests unchanged',all(x['unchanged'] for x in manifest))
