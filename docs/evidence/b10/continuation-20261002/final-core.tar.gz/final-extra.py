import pathlib,subprocess,os,json,time,signal
out=pathlib.Path('/workspace/b10-work/final-extra');out.mkdir(exist_ok=True);cwd='/workspace/nihon/app';env={**os.environ,'PLAYWRIGHT_BROWSERS_PATH':'/workspace/b10-work/browsers','NIHON_CHROMIUM_PATH':'/usr/bin/chromium','NIHON_WEBKIT_PATH':'/workspace/b10-work/webkit','NIHON_BASE_URL':'http://127.0.0.1:4181'};head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=cwd,text=True).strip();jobs=[]
for script in ['b10-microcopy-check.mjs','block20-place-detail-check.mjs']:
 for engine in ['chromium','webkit']:jobs.append((script[:-4]+'-'+engine,['node','scripts/'+script],{'NIHON_BROWSER':engine}))
for engine in ['chromium','webkit']:
 for v in ['mobile','desktop']:jobs.append(('b21-'+engine+'-'+v,['node','scripts/b21-global-search-browser-audit.mjs','--viewport='+v],{'NIHON_BROWSER':engine}))
for script in ['block19-discovery-browser-audit.mjs','block19-grid-check.mjs','block19-contrast-check.mjs','block22-b6-6-photography-browser-audit.mjs','block23-photo-retry-browser-audit.mjs','b18-responsive-check.mjs','b18-chrome-check.mjs','b18-a11y-check.mjs','b18-viaje-lugar-check.mjs']:
 jobs.append((script[:-4],['node','scripts/'+script],{}))
results=[]
for name,cmd,extra in jobs:
 start=time.time()
 with(out/(name+'.log')).open('w')as log:
  log.write(json.dumps({'cmd':cmd,'head':head,'env':{k:v for k,v in {**env,**extra}.items()if k.startswith(('NIHON','PLAYWRIGHT'))}})+'\n');log.flush();p=subprocess.Popen(cmd,cwd=cwd,env={**env,**extra},stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try:code=p.wait(timeout=900)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait();code='watchdog-900s'
 results.append({'name':name,'exit':code,'head':head,'seconds':round(time.time()-start,2)});(out/'results.json').write_text(json.dumps(results,indent=2));print(name,code,flush=True)
