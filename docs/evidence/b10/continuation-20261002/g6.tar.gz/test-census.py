import subprocess,json,re,pathlib
root='/workspace/nihon';initial='23e112f';refs=['b854db384c952e827b86d1bb35cac7caa70b035a','40838062062c8820ea9f7b028675d8add0c96c32','e124591','23e112f']
inventory={}
for ref in refs:
 names=subprocess.check_output(['git','ls-tree','-r','--name-only',ref,'app'],cwd=root,text=True).splitlines(); files={}
 for n in names:
  if re.search(r'\.test\.(?:tsx?|mjs)$',n):
   s=subprocess.check_output(['git','show',ref+':'+n],cwd=root,text=True);files[n]={'declarations':len(re.findall(r'\b(?:it|test)\s*\(',s)),'blob':subprocess.check_output(['git','rev-parse',ref+':'+n],cwd=root,text=True).strip()}
 inventory[ref]=files
changes=[]
base=refs[0];final=refs[-1]
for n in sorted(set(inventory[base])|set(inventory[final])):
 a=inventory[base].get(n);b=inventory[final].get(n)
 if a!=b:
  diff=subprocess.check_output(['git','diff',base,final,'--',n],cwd=root,text=True);changes.append({'path':n,'before':a,'after':b,'diff':diff})
out=pathlib.Path('/workspace/b10-work/history');(out/'test-census.json').write_text(json.dumps({'method':'static declarations are not runtime totals; compare executed Vitest inventory separately','inventory':inventory,'changes':changes},indent=2));print([(r['path'],r['before'] and r['before']['declarations'],r['after'] and r['after']['declarations'])for r in changes]);print({r:len(f)for r,f in inventory.items()})
