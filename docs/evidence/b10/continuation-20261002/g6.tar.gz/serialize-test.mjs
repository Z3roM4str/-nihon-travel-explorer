import fs from 'node:fs';
const source=JSON.parse(fs.readFileSync('/workspace/nihon/app/src/data/photography-metadata.json'));
const fields=['placeId','assetPath','alt','source','sourceUrl','credit','license','licenseUrl','originalTitle','attributionTitle','processing'];
const data={images:source.images.map(r=>Object.fromEntries(fields.filter(k=>k in r).map(k=>[k,r[k]])))};
const counts=new Map();function count(v){if(typeof v==='string')counts.set(v,(counts.get(v)||0)+1);else if(v&&typeof v==='object')Object.values(v).forEach(count)}count(data);
const repeated=new Map([...counts].filter(([s,n])=>n>1&&s.length>=24).map(([s],i)=>[s,`_s${i}`]));
function serialize(v){if(typeof v==='string')return repeated.get(v)||JSON.stringify(v);if(Array.isArray(v))return `[${v.map(serialize).join(',')}]`;if(v&&typeof v==='object')return `{${Object.entries(v).map(([k,x])=>`${JSON.stringify(k)}:${serialize(x)}`).join(',')}}`;return JSON.stringify(v)}
fs.writeFileSync('/workspace/b10-work/photo-module.js',`${[...repeated].map(([s,n])=>`const ${n}=${JSON.stringify(s)};`).join('\n')}\nexport default ${serialize(data)}`);
console.log(repeated.size)
